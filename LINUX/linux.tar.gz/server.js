// server.js
// Démarrage:  npm init -y && npm i express bcrypt jsonwebtoken cookie-parser multer sqlite3 uuid mime-types
// Lancer:     node server.js
// LAN:        écoute sur 0.0.0.0  → http://<IP_LAN>:8000

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const mime = require('mime-types');
const { v4: uuidv4 } = require('uuid');

// ---------------- Configuration ----------------
const app = express();
const PORT = process.env.PORT || 7000;
const HOST = process.env.HOST || '0.0.0.0';
const JWT_SECRET = process.env.JWT_SECRET || 'clem';
const MAX_QUOTA = 5 * 1024 * 1024 * 1024; // 5 Go
const STORAGE_ROOT = path.join(__dirname, 'storage');
const TMP_DIR = path.join(__dirname, 'tmp');

// Limite d'upload à 3 Go par fichier (DEMANDE 2)
const upload = multer({
  dest: TMP_DIR,
  limits: { fileSize: 1 * 1024 * 1024 * 1024 } // 1 Go
});

if (!fs.existsSync(STORAGE_ROOT)) fs.mkdirSync(STORAGE_ROOT, { recursive: true });
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

app.use(express.json());
app.use(cookieParser());

// ---------------- Base de données ----------------
const db = new sqlite3.Database(path.join(__dirname, 'app.db'));
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      passwordHash TEXT NOT NULL,
      usedSpace INTEGER NOT NULL DEFAULT 0,
      createdAt TEXT NOT NULL
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      originalName TEXT NOT NULL,
      storedName TEXT NOT NULL,
      size INTEGER NOT NULL,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(userId) REFERENCES users(id)
    )
  `);
});

// Promesses utilitaires
const run = (sql, params = []) =>
  new Promise((resolve, reject) => db.run(sql, params, function (err) { err ? reject(err) : resolve(this); }));

const get = (sql, params = []) =>
  new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));

const all = (sql, params = []) =>
  new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));

// ---------------- Helpers ----------------
const sanitizeUsername = (u) => String(u).trim().replace(/[^\w.-]/g, '_');
const ensureUserDir = (username) => {
  const dir = path.join(STORAGE_ROOT, sanitizeUsername(username));
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};
const formatBytes = (bytes) => {
  const units = ['B','KB','MB','GB','TB'];
  let i = 0, v = bytes;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(2)} ${units[i]}`;
};

// ---------------- Auth ----------------
const signToken = (payload) => jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });

const authRequired = async (req, res, next) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Non authentifié' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET); // { id, username }
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: 'Session invalide' });
  }
};

// ---------------- Routes Auth ----------------
app.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'username et password requis' });
    if (String(username).length < 3) return res.status(400).json({ error: 'username trop court (>=3)' });
    if (String(password).length < 6) return res.status(400).json({ error: 'password trop court (>=6)' });
    if (!/^[\w.-]+$/.test(username)) return res.status(400).json({ error: 'username invalide (lettres, chiffres, tirets et points autorisés)' });

    const exists = await get('SELECT id FROM users WHERE username = ?', [username]);
    if (exists) return res.status(409).json({ error: 'username déjà utilisé' });
    if (username.toLowerCase() === 'admin') return res.status(400).json({ error: 'username "admin" réservé' });
    if (username.toLowerCase() === 'anonymous') return res.status(400).json({ error: 'username "anonymous" réservé' });

    const passwordHash = await bcrypt.hash(password, 12);
    const createdAt = new Date().toISOString();
    const r = await run('INSERT INTO users (username, passwordHash, usedSpace, createdAt) VALUES (?, ?, 0, ?)', [username, passwordHash, createdAt]);
    ensureUserDir(username);

    const token = signToken({ id: r.lastID, username });
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: !!process.env.HTTPS,
      maxAge: 7 * 24 * 60 * 60 * 1000
    });
    console.info(`REGISTER: ${username} a été créé avec ID ${r.lastID} et quota ${MAX_QUOTA} octets  (30 Go)`);
    return res.status(201).json({ message: 'Compte créé', user: { id: r.lastID, username }, quota: { used: 0, max: MAX_QUOTA } });
  } catch (e) {
    console.error('REGISTER', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'username et password requis' });

    const u = await get('SELECT * FROM users WHERE username = ?', [username]);
    if (!u) return res.status(401).json({ error: 'Utilisateur inconnu' });

    const ok = await bcrypt.compare(password, u.passwordHash);
    if (!ok) return res.status(401).json({ error: 'Mot de passe invalide' });

    const token = signToken({ id: u.id, username: u.username });
    res.cookie('token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: !!process.env.HTTPS,
      maxAge: 7 * 24 * 60 * 60 * 1000
    });
    res.json({ message: 'Connecté', user: { id: u.id, username: u.username }, quota: { used: u.usedSpace, max: MAX_QUOTA } });
    console.info(`LOGIN: ${u.username} a été connecté`);
  } catch (e) {
    console.error('LOGIN', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.post('/logout', (req, res) => {
  const username = req.user && req.user.username ? req.user.username : 'anonyme';
  console.info(`LOGOUT: ${username} a été déconnecté`);
  res.clearCookie('token');
  res.json({ message: 'Déconnecté' });
});

app.get('/me', authRequired, async (req, res) => {
  try {
    const u = await get('SELECT id, username, usedSpace FROM users WHERE id = ?', [req.user.id]);
    if (!u) return res.status(404).json({ error: 'Utilisateur introuvable' });
    res.json({ user: u, quota: { used: u.usedSpace, max: MAX_QUOTA } });
  } catch (e) {
    console.error('ME', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---------------- Upload & Fichiers ----------------

// Upload (avec limite 3 Go – conservé, seule la const upload a changé)
app.post('/upload', authRequired, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Aucun fichier' });

    const u = await get('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (!u) {
      fs.unlinkSync(req.file.path);
      return res.status(404).json({ error: 'Utilisateur introuvable' });
    }

    if (u.usedSpace + req.file.size > MAX_QUOTA) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ error: 'Quota dépassé (achete moi un disque dur ou un ssd externe)' });
    }

    const userDir = ensureUserDir(u.username);
    const ext = path.extname(req.file.originalname);
    const safeBase = path.basename(req.file.originalname, ext).replace(/[^\w.\- ]+/g, '_');
    const storedName = `${safeBase}-${uuidv4()}${ext}`;
    const dest = path.join(userDir, storedName);
  // ENCODAGE: lit le fichier temporaire, encode en base64, puis écrit le fichier encodé
  const fileBuffer = fs.readFileSync(req.file.path);
  const encoded = Buffer.from(fileBuffer).toString('base64');
  fs.writeFileSync(dest, encoded, 'utf-8');
  fs.unlinkSync(req.file.path);

    const createdAt = new Date().toISOString();
    await run('INSERT INTO files (userId, originalName, storedName, size, createdAt) VALUES (?, ?, ?, ?, ?)', [
      u.id, req.file.originalname, storedName, req.file.size, createdAt
    ]);
    await run('UPDATE users SET usedSpace = usedSpace + ? WHERE id = ?', [req.file.size, u.id]);

    res.json({ message: 'Fichier envoyé', size: req.file.size });
    console.info(`UPLOAD: ${u.username} a envoyé ${req.file.originalname} (${formatBytes(req.file.size)})`);
  } catch (e) {
    console.error('UPLOAD', e);
    try { if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path); } catch {}
    res.status(500).json({ error: 'Erreur upload' });
  }
});

app.get('/files', authRequired, async (req, res) => {
  try {
    const rows = await all('SELECT id, originalName, storedName, size, createdAt FROM files WHERE userId = ? ORDER BY createdAt DESC', [req.user.id]);
    const files = rows.map(r => ({
      id: r.id,
      originalName: r.originalName,
      size: r.size,
      createdAt: r.createdAt,
      mimeType: mime.lookup(r.originalName) || 'application/octet-stream'
    }));
    res.json({ files });
  } catch (e) {
    console.error('FILES', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Renommer
app.post('/files/:id/rename', authRequired, async (req, res) => {
  try {
    const { newName } = req.body || {};
    if (!newName || typeof newName !== 'string' || !newName.trim()) {
      return res.status(400).json({ error: 'Nouveau nom invalide' });
    }
    const f = await get(
      'SELECT f.*, u.username FROM files f JOIN users u ON u.id = f.userId WHERE f.id = ? AND f.userId = ?',
      [req.params.id, req.user.id]
    );
    if (!f) return res.status(404).json({ error: 'Fichier introuvable' });

    const userDir = path.join(STORAGE_ROOT, sanitizeUsername(f.username));
    const oldPath = path.join(userDir, f.storedName);

    const ext = path.extname(newName);
    const safeBase = path.basename(newName, ext).replace(/[^\w.\- ]+/g, '_');
    const newStoredName = `${safeBase}-${uuidv4()}${ext}`;
    const newPath = path.join(userDir, newStoredName);

    if (!fs.existsSync(oldPath)) return res.status(404).json({ error: 'Fichier absent du stockage' });

    fs.renameSync(oldPath, newPath);
    await run('UPDATE files SET originalName = ?, storedName = ? WHERE id = ?', [newName, newStoredName, f.id]);
    res.json({ message: 'Fichier renommé', originalName: newName });
  } catch (e) {
    console.error('RENAME', e);
    res.status(500).json({ error: 'Erreur renommage' });
  }
});

// Preview
app.get('/preview/:id', authRequired, async (req, res) => {
  try {
    const f = await get(
      'SELECT f.*, u.username FROM files f JOIN users u ON u.id = f.userId WHERE f.id = ? AND f.userId = ?',
      [req.params.id, req.user.id]
    );
    if (!f) return res.status(404).json({ error: 'Fichier introuvable' });

    const filePath = path.join(STORAGE_ROOT, sanitizeUsername(f.username), f.storedName);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Fichier absent du stockage' });

    const type = mime.lookup(f.originalName) || 'application/octet-stream';
    // Décodage base64 pour preview
    const encoded = fs.readFileSync(filePath, 'utf-8');
    const buffer = Buffer.from(encoded, 'base64');
    if (type.startsWith('text/')) {
      res.type(type).send(buffer.toString('utf-8'));
    } else if (type.startsWith('image/') || type.startsWith('video/')) {
      res.type(type).send(buffer);
    } else {
      res.status(415).json({ error: 'Aperçu non supporté pour ce type de fichier' });
    }
  } catch (e) {
    console.error('PREVIEW', e);
    res.status(500).json({ error: 'Erreur preview' });
  }
});

// Download
app.get('/download/:id', authRequired, async (req, res) => {
  try {
    const f = await get(
      'SELECT f.*, u.username FROM files f JOIN users u ON u.id = f.userId WHERE f.id = ? AND f.userId = ?',
      [req.params.id, req.user.id]
    );
    if (!f) return res.status(404).json({ error: 'Fichier introuvable' });

    const filePath = path.join(STORAGE_ROOT, sanitizeUsername(f.username), f.storedName);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Fichier absent du stockage' });

  // Décodage base64 pour download
  const encoded = fs.readFileSync(filePath, 'utf-8');
  const buffer = Buffer.from(encoded, 'base64');
  res.setHeader('Content-Disposition', `attachment; filename="${f.originalName}"`);
  res.setHeader('Content-Type', mime.lookup(f.originalName) || 'application/octet-stream');
  res.send(buffer);
    console.info(`DOWNLOAD: ${req.user.username} a téléchargé ${f.originalName} (${formatBytes(f.size)})`);
  } catch (e) {
    console.error('DOWNLOAD', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Delete
app.delete('/files/:id', authRequired, async (req, res) => {
  try {
    const f = await get(
      'SELECT f.*, u.username FROM files f JOIN users u ON u.id = f.userId WHERE f.id = ? AND f.userId = ?',
      [req.params.id, req.user.id]
    );
    if (!f) return res.status(404).json({ error: 'Fichier introuvable' });

    const filePath = path.join(STORAGE_ROOT, sanitizeUsername(f.username), f.storedName);
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (e) { console.warn('unlink', e.message); }

    await run('DELETE FROM files WHERE id = ?', [f.id]);
    // CASE pour éviter les valeurs négatives (SQLite)
    await run(
      'UPDATE users SET usedSpace = CASE WHEN usedSpace - ? < 0 THEN 0 ELSE usedSpace - ? END WHERE id = ?',
      [f.size, f.size, f.userId]
    );

    res.json({ message: 'Fichier supprimé' });
    console.info(`DELETE: ${req.user.username} a supprimé ${f.originalName} (${formatBytes(f.size)})`);
  } catch (e) {
    console.error('DELETE', e);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---------------- ÉDITION DE FICHIERS TEXTE (DEMANDE 1) ----------------
// Sauvegarde du contenu texte (en UTF-8). On autorise tout type de Content-Type.
app.post('/files/:id/update', authRequired, express.text({ type: '*/*', limit: '200mb' }), async (req, res) => {
  try {
    const f = await get(
      'SELECT f.*, u.username FROM files f JOIN users u ON u.id = f.userId WHERE f.id = ? AND f.userId = ?',
      [req.params.id, req.user.id]
    );
    if (!f) return res.status(404).json({ error: 'Fichier introuvable' });

    const type = mime.lookup(f.originalName) || 'application/octet-stream';
    if (!type.startsWith('text/')) {
      return res.status(415).json({ error: 'Édition limitée aux fichiers texte' });
    }

    const filePath = path.join(STORAGE_ROOT, sanitizeUsername(f.username), f.storedName);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Fichier absent du stockage' });

    // Pour éviter d'écraser un fichier binaire par erreur, on vérifie bien le type
    // Liste des extensions éditables
    const editableExts = [
      '.txt','.md','.js','.json','.html','.css','.py','.csv','.xml','.yml','.yaml','.sh','.bat','.ini','.conf','.log','.ts','.jsx','.tsx','.php','.c','.cpp','.h','.hpp','.java','.rb','.go','.rs','.pl','.lua','.toml','.env','.scss','.less','.sass','.vue','.swift','.kt','.dart','.cs','.asp','.jsp','.sql','.r','.ps1','.properties','.cfg','.tex','.mak','.gradle','.dockerfile','.gitignore','.gitattributes','.editorconfig'
    ];
    const ext = (f.originalName.match(/\.[^\.]+$/) || [''])[0].toLowerCase();
    if (!editableExts.includes(ext)) {
      return res.status(415).json({ error: 'Édition limitée aux fichiers texte ou code source courants' });
    }

    // ENCODAGE: on encode le texte en base64 avant de sauvegarder
    const encoded = Buffer.from(req.body ?? '', 'utf-8').toString('base64');
    fs.writeFileSync(filePath, encoded, 'utf-8');
    res.json({ message: 'Fichier mis à jour' });
  } catch (e) {
    console.error('UPDATE_TEXT', e);
    res.status(500).json({ error: 'Erreur sauvegarde' });
  }
});

// ---------------- Listing des comptes (protégé) ----------------
app.get('/accounts', authRequired, async (req, res) => {
  try {
    const users = await all('SELECT id, username FROM users ORDER BY username ASC');
    const data = {};
    for (const u of users) {
      const files = await all('SELECT originalName, storedName, size, createdAt FROM files WHERE userId = ? ORDER BY createdAt DESC', [u.id]);
      data[u.username] = files;
    }
    const outPath = path.join(__dirname, 'list_accounts.json');
    fs.writeFileSync(outPath, JSON.stringify(data, null, 2), 'utf-8');
    res.json(data);
  } catch (e) {
    console.error('ACCOUNTS', e);
    res.status(500).json({ error: 'Erreur génération liste' });
  }
});

// ---------------- UI minimale tout-en-un ----------------
app.get('/', (req, res) => {
  res.type('html').send(`<!doctype html>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>FileUploader</title>
<style>
:root{--bg:#0f172a;--panel:#111827;--muted:#94a3b8;--text:#e5e7eb;--accent:#4f46e5;--danger:#ef4444;--border:#1f2937}
*{box-sizing:border-box}body{margin:0;background:linear-gradient(145deg,#0b1022,#121a35);color:var(--text);font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;min-height:100vh;display:grid;place-items:center;padding:32px}
.container{width:100%;max-width:980px}.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.brand{font-weight:700;letter-spacing:.3px;font-size:19px}.card{background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;padding:22px;backdrop-filter:blur(8px);box-shadow:0 20px 50px rgba(0,0,0,.35)}
.grid{display:grid;gap:16px}.row{display:flex;gap:10px}.split{display:grid;grid-template-columns:1fr;gap:16px}@media(min-width:800px){.split{grid-template-columns:1fr 1fr}}
input[type=text],input[type=password],input[type=file]{width:100%;padding:12px 14px;border-radius:10px;border:1px solid var(--border);background:#0b1224;color:var(--text);outline:none}
button{border:0;background:var(--accent);color:#fff;padding:12px 16px;border-radius:10px;cursor:pointer;transition:transform .05s,filter .2s;font-weight:600}button:hover{filter:brightness(1.05)}button:active{transform:translateY(1px)}
.btn-secondary{background:#2d3748}.btn-danger{background:var(--danger)}.muted{color:var(--muted)}.quota{font-size:14px}
ul{list-style:none;padding:0;margin:0}li.file{display:flex;align-items:center;justify-content:space-between;border:1px solid var(--border);border-radius:10px;padding:10px 12px;margin-bottom:8px;background:#0b1224}
a{color:#93c5fd;text-decoration:none}a:hover{text-decoration:underline}.title{margin:0 0 10px 0}.right{display:flex;gap:8px;align-items:center}.tag{background:#0a182e;border:1px solid var(--border);padding:4px 8px;border-radius:8px;font-size:12px;color:var(--muted)}
.progress-wrap{margin-top:10px}
.progress{width:100%;height:10px;background:#0a182e;border:1px solid var(--border);border-radius:999px;overflow:hidden}
.progress>.bar{height:100%;width:0%}
.progress-info{font-size:12px;margin-top:6px;color:var(--muted)}
.bar{background:linear-gradient(90deg,#4f46e5,#22d3ee)}
.modal{display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,.85);z-index:9999;justify-content:center;align-items:center}
.modal-card{background:#181e2a;padding:24px;border-radius:12px;max-width:90vw;max-height:90vh;overflow:auto;position:relative}
textarea.editor{width:70vw;max-width:80vw;height:60vh;max-height:80vh;background:#23293a;color:#e5e7eb;border:1px solid var(--border);border-radius:10px;padding:12px;outline:none;resize:vertical}
</style>
<div class="container">
  <div class="header">
    <!-- <div class="brand">centre de fichier</div></d> -->
    <div class="brand"><h2>les stockages sont maintenant limités à 5 Go par utilisateur</h2></div>
    <div class="right">
      <span id="userTag" class="tag" style="display:none;"></span>
      <button id="logoutBtn" class="btn-secondary" style="display:none;">Se déconnecter</button></d>
    </div>
  </div>

  <div id="authView" class="card" style="display:none;">
    <h2 class="title">Bienvenue</h2>
    <p class="muted">Connecte-toi ou inscris-toi pour commencer à envoyer des fichiers.</p>
    <div class="split">
      <form id="loginForm">
        <h3>Connexion</h3>
        <div class="grid">
          <input name="username" placeholder="Nom d'utilisateur" type="text" required />
          <input name="password" placeholder="Mot de passe" type="password" required />
          <button>Se connecter</button>
        </div>
      </form>

      <form id="registerForm">
        <h3>Inscription</h3>
        <div class="grid">
          <input name="username" placeholder="Nom d'utilisateur" type="text" required />
          <input name="password" placeholder="Mot de passe (>= 6)" type="password" required />
          <button class="btn-secondary">Créer le compte</button>
        </div>
      </form>
    </div>
  </div>

  <div id="appView" class="card" style="display:none;">
    <h2 class="title">Mon espace</h2>
    <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:10px;">
      <div class="quota" id="quota"></div>
      <div class="right"><button id="refreshBtn" class="btn-secondary">Rafraîchir</button></div>
    </div>

    <div class="card" style="margin-top:12px;">
      <h3>Envoyer un fichier</h3>
      <form id="uploadForm" enctype="multipart/form-data" class="row">
        <input type="file" name="file" required />
        <button id="uploadBtn">Envoyer</button>
      </form>
      <div class="progress-wrap" id="progressWrap" style="display:none;">
        <div class="progress"><div class="bar" id="progressBar"></div></div>
        <div class="progress-info" id="progressInfo"></div>
      </div>
      <p class="muted" id="hint"></p>
      <p class="muted">Limite par fichier: 1 Go</p>
    </div>

    <div class="card" style="margin-top:12px;">
      <h3>Mes fichiers</h3>
      <ul id="files"></ul>
    </div>
  </div>
</div>

<!-- Modale preview/édition -->
<div id="previewModal" class="modal"><div id="previewContent" class="modal-card"></div></div>

<script>
async function api(path, opts={}) {
  const res = await fetch(path, { credentials: 'include', ...opts });
  const text = await res.text();
  try { return { status: res.status, data: JSON.parse(text) }; }
  catch { return { status: res.status, data: text }; }
}
function showAuth(){ authView.style.display='block'; appView.style.display='none'; logoutBtn.style.display='none'; userTag.style.display='none'; }
function showApp(){ authView.style.display='none'; appView.style.display='block'; logoutBtn.style.display='inline-block'; userTag.style.display='inline-block'; }
function formatBytes(bytes){ const u=['B','KB','MB','GB','TB']; let i=0,v=bytes; while(v>=1024&&i<u.length-1){v/=1024;i++;} return v.toFixed(2)+' '+u[i]; }

async function loadMe(){
  const r = await api('/me');
  if (r.status===200){
    const { user, quota } = r.data;
    userTag.textContent = user.username;
    quotaEl.textContent = 'Espace utilisé: ' + formatBytes(quota.used) + ' / ' + formatBytes(quota.max);
    hint.textContent = 'Espace restant estimé: ' + formatBytes(Math.max(0, quota.max - quota.used));
    showApp(); await loadFiles();
  } else showAuth();
}

async function loadFiles(){
  const r = await api('/files');
  const ul = files;
  ul.innerHTML = '';
  if (r.status !== 200){ ul.innerHTML = '<li class="muted">Erreur de chargement</li>'; return; }
  for (const f of r.data.files){
    const li = document.createElement('li'); li.className='file';
    const left = document.createElement('div'); left.style.display='flex'; left.style.alignItems='center'; left.style.gap='10px';

    let thumb=null;
    if (f.mimeType.startsWith('image/')){ thumb=document.createElement('img'); thumb.src='/preview/'+f.id+'?t='+Date.now(); Object.assign(thumb.style,{width:'48px',height:'48px',objectFit:'cover',borderRadius:'6px'}); }
    else if (f.mimeType.startsWith('video/')){ thumb=document.createElement('video'); thumb.src='/preview/'+f.id+'?t='+Date.now(); Object.assign(thumb.style,{width:'48px',height:'48px',objectFit:'cover',borderRadius:'6px'}); thumb.muted=true; thumb.playsInline=true; thumb.onmouseover=()=>thumb.play(); thumb.onmouseout=()=>{thumb.pause(); thumb.currentTime=0;}; }
    if (thumb) left.appendChild(thumb);

    const nameSpan=document.createElement('span'); nameSpan.textContent = f.originalName+' • '+formatBytes(f.size); left.appendChild(nameSpan);

    const right=document.createElement('div'); right.className='right';

    if (/^(image|video|text)\\//.test(f.mimeType)){
      const openBtn=document.createElement('button'); openBtn.textContent='Ouvrir'; openBtn.className='btn-secondary'; openBtn.onclick=()=>openPreviewModal(f); right.appendChild(openBtn);
    }
    if (f.mimeType.startsWith('text/')){
      const editBtn=document.createElement('button'); editBtn.textContent='Éditer'; editBtn.className='btn-secondary'; editBtn.onclick=()=>openEditModal(f); right.appendChild(editBtn);
    }

    const dl=document.createElement('a'); dl.href='/download/'+f.id; dl.textContent='Télécharger'; dl.className='btn-secondary'; dl.style.marginRight='6px'; right.appendChild(dl);

    const renBtn=document.createElement('button'); renBtn.textContent='Renommer'; renBtn.className='btn-secondary'; renBtn.onclick=async()=>{
      const newName=prompt('Nouveau nom du fichier ?', f.originalName);
      if(!newName || newName===f.originalName) return;
      const rr=await api('/files/'+f.id+'/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({newName})});
      alert(rr.data.message||rr.data.error||rr.status); loadMe();
    }; right.appendChild(renBtn);

    const del=document.createElement('button'); del.className='btn-danger'; del.textContent='Supprimer'; del.onclick=async()=>{
      if(!confirm('Supprimer ce fichier ?')) return;
      const rr=await api('/files/'+f.id,{method:'DELETE'}); alert(rr.data.message||rr.data.error||rr.status); loadMe();
    }; right.appendChild(del);

    li.appendChild(left); li.appendChild(right); ul.appendChild(li);
  }
}

function ensureModal(){
  const modal=document.getElementById('previewModal');
  const content=document.getElementById('previewContent');
  return { modal, content };
}

async function openPreviewModal(f){
  const { modal, content } = ensureModal();
  content.innerHTML='';
  let el;
  if (f.mimeType.startsWith('image/')){ el=document.createElement('img'); el.src='/preview/'+f.id+'?t='+Date.now(); Object.assign(el.style,{maxWidth:'80vw',maxHeight:'80vh',borderRadius:'10px'}); }
  else if (f.mimeType.startsWith('video/')){ el=document.createElement('video'); el.src='/preview/'+f.id+'?t='+Date.now(); el.controls=true; el.autoplay=true; el.muted=true; Object.assign(el.style,{maxWidth:'80vw',maxHeight:'80vh',borderRadius:'10px'}); el.addEventListener('loadeddata',()=>{el.play().catch(()=>{});el.focus();}); }
  else if (f.mimeType.startsWith('text/')){ const resp=await fetch('/preview/'+f.id,{credentials:'include'}); const txt=await resp.text(); el=document.createElement('pre'); el.textContent=txt; Object.assign(el.style,{maxWidth:'80vw',maxHeight:'80vh',overflow:'auto',background:'#23293a',color:'#e5e7eb',padding:'18px',borderRadius:'10px'}); }
  else { el=document.createElement('div'); el.textContent='Aperçu non supporté.'; el.style.color='#ef4444'; }
  content.appendChild(el);
  const closeBtn=document.createElement('button'); closeBtn.textContent='Fermer'; closeBtn.className='btn-secondary'; Object.assign(closeBtn.style,{position:'absolute',top:'12px',right:'12px'}); closeBtn.onclick=()=>{modal.style.display='none';}; content.appendChild(closeBtn);
  modal.onclick=(e)=>{ if(e.target===modal) modal.style.display='none'; };
  modal.style.display='flex';
}

// ÉDITEUR TEXTE (DEMANDE 1)
async function openEditModal(f){
  const { modal, content } = ensureModal();
  content.innerHTML='';
  // Charge le texte actuel
  const resp = await fetch('/preview/'+f.id,{credentials:'include'});
  if (resp.status!==200){ alert('Impossible de charger le fichier'); return; }
  const txt = await resp.text();

  const title=document.createElement('div');
  title.textContent='Éditer : '+f.originalName;
  title.style.marginBottom='10px';
  content.appendChild(title);

  const textarea=document.createElement('textarea');
  textarea.className='editor';
  textarea.value=txt;
  content.appendChild(textarea);

  const actions=document.createElement('div');
  actions.style.marginTop='12px';
  actions.style.display='flex';
  actions.style.gap='8px';

  const saveBtn=document.createElement('button');
  saveBtn.textContent='Sauvegarder';
  saveBtn.className='btn-secondary';
  saveBtn.onclick=async()=>{
    const res=await fetch('/files/'+f.id+'/update',{
      method:'POST',
      credentials:'include',
      headers:{'Content-Type':'text/plain;charset=utf-8'},
      body:textarea.value
    });
    const t = await res.text(); let j; try{ j=JSON.parse(t);}catch{ j={message:t};}
    alert(j.message||j.error||res.status);
    if (res.ok){ modal.style.display='none'; loadMe(); }
  };
  const cancelBtn=document.createElement('button');
  cancelBtn.textContent='Fermer';
  cancelBtn.className='btn-secondary';
  cancelBtn.onclick=()=>{ modal.style.display='none'; };

  actions.appendChild(saveBtn);
  actions.appendChild(cancelBtn);
  content.appendChild(actions);

  modal.onclick=(e)=>{ if(e.target===modal) modal.style.display='none'; };
  modal.style.display='flex';
}

const authView=document.getElementById('authView');
const appView=document.getElementById('appView');
const logoutBtn=document.getElementById('logoutBtn');
const userTag=document.getElementById('userTag');
const quotaEl=document.getElementById('quota');
const hint=document.getElementById('hint');
const files=document.getElementById('files');

document.getElementById('registerForm').onsubmit = async (e)=>{
  e.preventDefault();
  const form=e.target;
  const r=await api('/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:form.username.value,password:form.password.value})});
  alert(r.data.message||r.data.error||r.status); loadMe();
};
document.getElementById('loginForm').onsubmit = async (e)=>{
  e.preventDefault();
  const form=e.target;
  const r=await api('/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:form.username.value,password:form.password.value})});
  alert(r.data.message||r.data.error||r.status); loadMe();
};
logoutBtn.onclick=async()=>{ const r=await api('/logout',{method:'POST'}); alert(r.data.message||r.data.error||r.status); loadMe(); };
document.getElementById('refreshBtn').onclick=loadMe;

// UPLOAD AVEC BARRE DE PROGRESSION (DEMANDE 3)
document.getElementById('uploadForm').onsubmit=async(e)=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  const bar=document.getElementById('progressBar');
  const info=document.getElementById('progressInfo');
  const wrap=document.getElementById('progressWrap');
  const btn=document.getElementById('uploadBtn');
  wrap.style.display='block';
  bar.style.width='0%';
  info.textContent='Préparation...';
  btn.disabled=true;

  const start=Date.now();
  let lastLoaded=0, lastTime=start;

  // Utilise XMLHttpRequest pour onprogress (fiable + précis)
  const xhr=new XMLHttpRequest();
  xhr.open('POST','/upload',true);
  xhr.withCredentials=true;

  xhr.upload.onprogress=(e)=>{
    if (!e.lengthComputable) { info.textContent='Envoi en cours...'; return; }
    const percent = (e.loaded / e.total) * 100;
    bar.style.width = percent.toFixed(2)+'%';

    // calcul vitesse/ETA
    const now=Date.now();
    const deltaBytes=e.loaded - lastLoaded;
    const deltaTime=(now - lastTime)/1000;
    if (deltaTime>0) {
      const speed = deltaBytes / deltaTime; // B/s
      const remaining = e.total - e.loaded;
      const eta = speed>0 ? remaining / speed : 0;
      info.textContent = 
        percent.toFixed(2)+'% • '+
        'Vitesse: '+formatBytes(speed)+'/s • '+
        'Restant: '+formatBytes(remaining)+' • '+
        'ETA: '+(eta>0?Math.ceil(eta)+'s':'-');
      lastLoaded=e.loaded; lastTime=now;
    }
  };

  xhr.onload=async()=>{
    btn.disabled=false;
    if (xhr.status===200) {
      info.textContent='Terminé ✔';
      alert(JSON.parse(xhr.responseText).message || 'OK');
    } else {
      try { const j=JSON.parse(xhr.responseText); alert(j.error||j.message||xhr.status); }
      catch { alert(xhr.responseText || xhr.status); }
      info.textContent='Échec ';
    }
    loadMe();
  };

  xhr.onerror=()=>{
    btn.disabled=false;
    info.textContent='Erreur réseau';
    alert('Erreur réseau');
  };

  xhr.send(fd);
};

loadMe();
</script>`);
});

// ---------------- Lancement ----------------
app.listen(PORT, HOST, () => {
  console.log(`Serveur lancé sur http://${HOST}:${PORT}`);
});
